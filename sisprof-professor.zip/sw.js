/* SisProf: o sistema guardado no aparelho (02/11/2026, pedido do professor: "funcionar off-line e, quando tiver
   internet, subir tudo para a nuvem").
   · A página do sistema: primeiro a internet (para vir sempre a versão nova); sem internet, a cópia guardada.
   · As fontes e as bibliotecas de fora (Google Fonts, jsDelivr): a cópia guardada na hora, e atualiza por trás.
   · A nuvem (Supabase) NUNCA passa por aqui: os dados vão e voltam direto, e o que é do professor já é guardado no
     aparelho e enviado quando a internet volta (sincronia-modulos.js e offline.js).
   A versão abaixo muda a cada entrega: as cópias antigas são apagadas sozinhas. */
const VERSAO = "sisprof-20261103133023";
const PAGINA = "./";

self.addEventListener("install", ev => {
  ev.waitUntil(caches.open(VERSAO).then(c => c.addAll([PAGINA]).catch(() => {})).then(() => self.skipWaiting()));
});
self.addEventListener("activate", ev => {
  ev.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith("sisprof-") && k !== VERSAO).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
const deFora = url => /(^|\.)(fonts\.googleapis\.com|fonts\.gstatic\.com|cdn\.jsdelivr\.net)$/.test(url.hostname);
self.addEventListener("fetch", ev => {
  const req = ev.request; if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (/supabase\.co$/.test(url.hostname)) return;               /* a nuvem: direto, sem cópia */
  if (req.mode === "navigate" || (url.origin === self.location.origin && /\/(index\.html)?$/.test(url.pathname))) {
    ev.respondWith(fetch(req).then(r => { if (r && r.ok) { const cp = r.clone(); caches.open(VERSAO).then(c => c.put(PAGINA, cp)); } return r; })
      .catch(() => caches.open(VERSAO).then(c => c.match(PAGINA)).then(r => r || caches.match(PAGINA))));
    return;
  }
  if (deFora(url)) {
    ev.respondWith(caches.open(VERSAO).then(c => c.match(req).then(guardado => {
      const daRede = fetch(req).then(r => { if (r && (r.ok || r.type === "opaque")) c.put(req, r.clone()); return r; }).catch(() => guardado);
      return guardado || daRede; })));
  }
});
